function writeDocument(s){document.write(s);}
